#ifndef EADK_H
#define EADK_H
#include <stdint.h>
typedef uint16_t eadk_color_t; typedef struct {uint16_t x,y;} eadk_point_t; typedef struct {uint16_t x,y,width,height;} eadk_rect_t; typedef uint8_t eadk_key_t; typedef uint64_t eadk_keyboard_state_t;
#define EADK_SCREEN_WIDTH 320
#define EADK_SCREEN_HEIGHT 240
static inline void eadk_display_push_rect_uniform(eadk_rect_t,eadk_color_t){} static inline void eadk_display_draw_string(const char*,eadk_point_t,bool,eadk_color_t,eadk_color_t){} static inline bool eadk_keyboard_key_down(eadk_keyboard_state_t,eadk_key_t){return false;} static inline eadk_keyboard_state_t eadk_keyboard_scan(){return 0;} static inline void eadk_timing_msleep(uint32_t){}
#endif
