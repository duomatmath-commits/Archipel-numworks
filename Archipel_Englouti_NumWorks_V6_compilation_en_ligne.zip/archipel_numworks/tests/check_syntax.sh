#!/bin/sh
set -eu
c++ -std=c++11 -fsyntax-only -Wall -Wextra -Itests -Isrc src/main.cpp
c++ -std=c++11 -fsyntax-only -Wall -Wextra -Isrc src/storage/storage.cpp
echo 'Syntaxe C++ OK (verification hote uniquement, pas une compilation NumWorks).'
