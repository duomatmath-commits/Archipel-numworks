#include "eadkpp.h"
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include "storage/storage.h"

extern "C" {
const char eadk_app_name[] __attribute__((section(".rodata.eadk_app_name"))) = "Archipel Englouti";
const uint32_t eadk_api_level __attribute__((section(".rodata.eadk_api_level"))) = 0;
}
using namespace EADK;

/* ARCHIPEL ENGLOUTI - portage C++ natif NumWorks.
   Boucle deterministe, tableaux statiques, aucun Python / navigateur / heap en jeu. */
static const int W=320,H=240,MAXE=36,MAXS=24,WEAPONS=22,POWERS=19;
static const Color BLACK(0x000000),WHITE(0xffffff),NAVY(0x08246a),OCEAN(0x10b2ff),SAND(0xe6d6ac),GREEN(0x31b631),GOLD(0xffd600),RED(0xee3031),CYAN(0x5abaff),PURPLE(0xa459ff);
static uint32_t rng=0x91ac734du;
static uint32_t rnd32(){rng^=rng<<13;rng^=rng>>17;rng^=rng<<5;return rng;}
static int rnd(int n){return n>0?(int)(rnd32()%(uint32_t)n):0;}
static int ci(int v,int a,int b){return v<a?a:(v>b?b:v);}
static void box(int x,int y,int w,int h,Color c){if(w>0&&h>0)Display::pushRectUniform(Rect(x,y,w,h),c);}
static void txt(const char*s,int x,int y,Color f=WHITE,Color b=BLACK){Display::drawString(s,Point(x,y),true,f,b);}
static void clear(Color c=BLACK){box(0,0,W,H,c);}
static void bar(int x,int y,int w,int h,int v,int m,Color c){box(x,y,w,h,NAVY);if(m>0)box(x,y,ci(v*w/m,0,w),h,c);}
static int dist2(int x1,int y1,int x2,int y2){int x=x1-x2,y=y1-y2;return x*x+y*y;}

enum Scene{TITLE,PLAY,LEVELUP,CHEST,SHOP,POWERSELLER,FORGE,ARMORY,DEAD,VICTORY};
enum Role{COMMON,FAST,HEAVY,FLYER,BOSS};
struct Enemy{int x,y,hp,mhp,spd,dmg,role,alive,freeze,flash;};
struct Shot{int x,y,vx,vy,dmg,life,pierce,alive;};
struct Weapon{const char*name;int dmg,rate,count,pierce,owned,qty,level;Color color;};
struct Power{const char*name;int cost,cooldown,unlock;};
static Enemy E[MAXE];static Shot S[MAXS];
static Scene scene=TITLE;
static const char* islandNames[6]={"ILE DES CRABES","ILE VOLCANIQUE","BANQUISE","DESERT","MARECAGE","ILE CELESTE"};
static const char* bossNames[6]={"ROI DES CRABES","TITAN DE MAGMA","YETI ANCIEN","SPHINX DES SABLES","ROI DU MARECAGE","GRIFFON CELESTE"};
static const Color sea[6]={Color(0x10b2ff),Color(0xa45029),Color(0x29aeff),Color(0x29f641),Color(0x2085d5),Color(0x4a5062)};
static const Color land[6]={Color(0x31b631),Color(0x4144a4),Color(0xbdbe41),Color(0xee1820),Color(0x5a4cd5),Color(0xcdfac5)};
static Weapon weapons[WEAPONS]={
 {"ARC",10,17,1,0,1,1,0,GOLD},{"FRONDE",6,13,3,0,0,0,0,RED},{"ARBAL.ETE",24,29,1,1,0,0,0,WHITE},{"DAGUES",5,7,1,0,0,0,0,CYAN},
 {"BAGUETTE",9,14,1,1,0,0,0,PURPLE},{"SHURIKENS",6,10,3,0,0,0,0,WHITE},{"CANON",42,38,1,1,0,0,0,GOLD},{"TEMPETE",7,13,7,0,0,0,0,PURPLE},{"RAYON",4,3,1,1,0,0,0,CYAN},
 {"ARC ARCANIQUE",17,12,2,1,0,0,0,GOLD},{"LAMES FANTOMES",7,8,5,1,0,0,0,CYAN},{"CANON-TEMPETE",22,17,5,1,0,0,0,PURPLE},{"FRONDE PHOTON",8,14,4,1,0,0,0,CYAN},{"FRONDE CYCLONE",6,13,9,0,0,0,0,PURPLE},{"BARRAGE EPINEUX",9,13,5,0,0,0,0,GREEN},{"ARBAL. RUNIQUE",28,20,2,1,0,0,0,PURPLE},{"BALISTE SIEGE",62,42,1,1,0,0,0,GOLD},{"ARBAL. RAIL",11,8,1,1,0,0,0,CYAN},{"LAMES RUNIQUES",8,7,2,1,0,0,0,PURPLE},{"LAMES PHOTON",7,6,2,1,0,0,0,CYAN},{"SHURI-TEMPETE",6,8,7,1,0,0,0,PURPLE},{"SCEPTRE ORAGE",9,12,4,1,0,0,0,GOLD}
};
// Recettes fideles aux 13 fusions du jeu HTML : index des deux armes de base.
static const int recipeA[13]={0,3,6,1,1,1,2,2,2,3,3,5,4};
static const int recipeB[13]={4,5,7,8,7,0,4,6,8,4,8,7,7};
static const int recipeOut[13]={9,10,11,12,13,14,15,16,17,18,19,20,21};
static Power powers[POWERS]={
 {"BOULE DE FEU",12,120,0},{"FOUDRE",18,150,0},{"GEL",22,270,0},{"BOUCLIER",20,300,0},{"METEORE",25,180,1},{"VAMPIRISME",24,360,1},{"STALACTITES",26,210,2},{"BLIZZARD",30,330,2},{"AURORE",28,420,2},{"TORNADE",16,180,0},{"FRENESIE",18,360,0},{"PLUIE DE LAVE",26,210,1},{"AVALANCHE",28,300,2},{"SCARABEES",26,210,3},{"TEMPETE SABLE",30,330,3},{"MALEDICTION",30,270,4},{"BOURBIER",28,360,4},{"ECLAIR DIVIN",34,240,5},{"HALO",32,420,5}
};
static int px=160,py=125,hp=100,mhp=100,gold=0,xp=0,level=1,need=8,score=0;
static int island=0,wave=0,spawnLeft=0,spawnClock=0,alive=0,weapon=0,selected=0,choice[3]={0,1,2};
static int power=0,hasPower=0,powerCD=0,invuln=0,fireClock=0,gameTick=0,weaponOwnedCount=1,shopChoice=0,forgeA=0,forgeB=1,forgeMode=0;
static int bonusDamage=100,bonusRate=100,bonusSpeed=100,extraShots=0,shieldTicks=0,hasteTicks=0;
static int islandBest[6]={0,0,0,0,0,0};
static void resetEntities();
static void recalcOwned();
static bool saveAvailable=false;
static int activeSaveSlot=-1;
static uint32_t saveSequence=0;
struct SaveData {
  uint32_t magic, version, sequence;
  int32_t island, wave, hp, mhp, gold, xp, level, need, score, weapon;
  int32_t power, hasPower, bonusDamage, bonusRate, bonusSpeed, extraShots;
  int32_t islandBest[6];
  int32_t owned[WEAPONS], qty[WEAPONS], weaponLevel[WEAPONS], damage[WEAPONS], rate[WEAPONS];
  uint32_t checksum;
};
static const uint32_t SAVE_MAGIC=0x41524348u;
static uint32_t checksumSave(const SaveData &d){
  const uint8_t *p=(const uint8_t*)&d; uint32_t h=2166136261u;
  for(size_t i=0;i<offsetof(SaveData,checksum);i++){h^=p[i];h*=16777619u;} return h;
}
static bool readSaveSlot(int slot,SaveData &d){
  const char *name=slot==0?"archipel0.sav":"archipel1.sav"; size_t n=0;
  const char *p=extapp_fileRead(name,&n); if(!p||n!=sizeof(SaveData))return false;
  memcpy(&d,p,sizeof(d));
  if(d.magic!=SAVE_MAGIC||d.version!=1||d.checksum!=checksumSave(d))return false;
  if(d.island<0||d.island>5||d.wave<1||d.wave>60||d.weapon<0||d.weapon>=WEAPONS||d.hp<0||d.mhp<1)return false;
  return true;
}
static void saveNow(){
  if(scene!=SHOP) return;
  SaveData d; memset(&d,0,sizeof(d));
  d.magic=SAVE_MAGIC;d.version=1;d.sequence=++saveSequence;
  d.island=island;d.wave=wave;d.hp=hp;d.mhp=mhp;d.gold=gold;d.xp=xp;d.level=level;d.need=need;d.score=score;d.weapon=weapon;
  d.power=power;d.hasPower=hasPower;d.bonusDamage=bonusDamage;d.bonusRate=bonusRate;d.bonusSpeed=bonusSpeed;d.extraShots=extraShots;
  for(int i=0;i<6;i++)d.islandBest[i]=islandBest[i];
  for(int i=0;i<WEAPONS;i++){d.owned[i]=weapons[i].owned;d.qty[i]=weapons[i].qty;d.weaponLevel[i]=weapons[i].level;d.damage[i]=weapons[i].dmg;d.rate[i]=weapons[i].rate;}
  d.checksum=checksumSave(d);
  int target=activeSaveSlot==0?1:0; const char *name=target==0?"archipel0.sav":"archipel1.sav";
  if(extapp_fileExists(name))extapp_fileErase(name);
  if(extapp_fileWrite(name,(const char*)&d,sizeof(d))){activeSaveSlot=target;saveAvailable=true;}
}
static bool loadSave(){
  SaveData a,b;bool va=readSaveSlot(0,a),vb=readSaveSlot(1,b);if(!va&&!vb)return false;
  SaveData &d=(!vb||(va&&(int32_t)(a.sequence-b.sequence)>0))?a:b;
  activeSaveSlot=(&d==&a)?0:1;saveSequence=d.sequence;
  island=d.island;wave=d.wave;hp=d.hp;mhp=d.mhp;gold=d.gold;xp=d.xp;level=d.level;need=d.need;score=d.score;weapon=d.weapon;
  power=d.power;hasPower=d.hasPower;bonusDamage=d.bonusDamage;bonusRate=d.bonusRate;bonusSpeed=d.bonusSpeed;extraShots=d.extraShots;
  for(int i=0;i<6;i++)islandBest[i]=d.islandBest[i];
  for(int i=0;i<WEAPONS;i++){weapons[i].owned=d.owned[i];weapons[i].qty=d.qty[i];weapons[i].level=d.weaponLevel[i];weapons[i].dmg=d.damage[i];weapons[i].rate=d.rate[i];}
  recalcOwned();saveAvailable=true;return true;
}
static void clearSave(){if(extapp_fileExists("archipel0.sav"))extapp_fileErase("archipel0.sav");if(extapp_fileExists("archipel1.sav"))extapp_fileErase("archipel1.sav");saveAvailable=false;activeSaveSlot=-1;saveSequence=0;}
static void continueGame(){resetEntities();spawnLeft=0;spawnClock=0;scene=SHOP;shopChoice=0;}

static void resetEntities(){for(int i=0;i<MAXE;i++)E[i].alive=0;for(int i=0;i<MAXS;i++)S[i].alive=0;alive=0;}
static void recalcOwned(){weaponOwnedCount=0;for(int i=0;i<WEAPONS;i++)if(weapons[i].owned)weaponOwnedCount++;}
static void startWave(){wave++;spawnLeft=(wave%5==0)?1:(6+wave*3);spawnClock=0;}
static void newGame(){clearSave();px=160;py=125;hp=mhp=100;gold=xp=score=0;level=1;need=8;island=0;wave=0;weapon=0;power=0;hasPower=0;powerCD=0;bonusDamage=bonusRate=bonusSpeed=100;extraShots=0;shieldTicks=hasteTicks=0;for(int i=0;i<WEAPONS;i++){weapons[i].owned=(i==0);weapons[i].qty=(i==0);weapons[i].level=0;}resetEntities();startWave();scene=PLAY;}
static int nearest(){int q=-1,d=999999;for(int i=0;i<MAXE;i++)if(E[i].alive){int z=dist2(px,py,E[i].x,E[i].y);if(z<d){d=z;q=i;}}return q;}
static void spawnEnemy(){int slot=-1;for(int i=0;i<MAXE;i++)if(!E[i].alive){slot=i;break;}if(slot<0)return;bool boss=(wave%5==0&&spawnLeft==1);int side=rnd(4),x=0,y=0;if(side==0){x=9;y=36+rnd(165);}else if(side==1){x=311;y=36+rnd(165);}else if(side==2){x=15+rnd(290);y=33;}else{x=15+rnd(290);y=205;}
 int role=boss?BOSS:(wave>2&&rnd(5)==0?HEAVY:wave>1&&rnd(4)==0?FLYER:wave>1&&rnd(3)==0?FAST:COMMON);
 int base=role==BOSS?230+wave*34:role==HEAVY?58:role==FLYER?13:role==FAST?12:22;
 int islandScale[6]={100,150,200,250,300,350};int hpv=base*islandScale[island]/100+wave*(role==BOSS?12:4);
 Enemy&e=E[slot];e.x=x;e.y=y;e.role=role;e.hp=e.mhp=hpv;e.spd=(role==BOSS?1:role==HEAVY?1:role==FLYER?3:role==FAST?3:2)*(100+island*8)/100;e.dmg=(role==BOSS?18:role==HEAVY?14:role==FAST?8:10)*islandScale[island]/100;e.alive=1;e.freeze=e.flash=0;alive++;}
static void addShot(int tx,int ty,int dmg,int count,int pierce){int dx=tx-px,dy=ty-py;int len=1;while(dx*dx+dy*dy>len*len*64)len++;int vx=dx/len,vy=dy/len;if(!vx&&!vy)vx=8;for(int n=0;n<count;n++)for(int j=0;j<MAXS;j++)if(!S[j].alive){Shot&s=S[j];s.x=px;s.y=py;s.vx=vx+(count>1?(n-(count-1)/2)*2:0);s.vy=vy;s.dmg=dmg;s.life=28;s.pierce=pierce;s.alive=1;break;}}
static void killEnemy(int i){Enemy&e=E[i];e.alive=0;alive--;int boss=e.role==BOSS;score+=boss?20:1;gold+=boss?20:1;xp+=boss?10:1;if(xp>=need){xp-=need;level++;need+=3;choice[0]=rnd(7);choice[1]=rnd(7);choice[2]=rnd(7);selected=0;scene=LEVELUP;}if(boss){scene=CHEST;shopChoice=rnd(9);}}
static void damageEnemies(int x,int y,int radius,int dmg,int freeze){for(int i=0;i<MAXE;i++)if(E[i].alive&&dist2(x,y,E[i].x,E[i].y)<radius*radius){E[i].hp-=dmg;E[i].freeze=freeze;if(E[i].hp<=0)killEnemy(i);}}
static void castPower(){if(!hasPower||powerCD>0||scene!=PLAY)return;powerCD=powers[power].cooldown;int t=nearest();switch(power){case 0:if(t>=0)damageEnemies(E[t].x,E[t].y,70,80+wave*3,0);break;case 1:case 17:for(int n=0;n<(power==1?5:8);n++){int q=nearest();if(q<0)break;damageEnemies(E[q].x,E[q].y,18,power==1?48:72,0);E[q].freeze=1;}break;case 2:case 6:case 7:case 12:case 14:for(int i=0;i<MAXE;i++)if(E[i].alive&&dist2(px,py,E[i].x,E[i].y)<125*125){E[i].freeze=power==2?90:power==6?30:power==7?100:power==12?90:75;E[i].hp-=power==7?45:24;if(E[i].hp<=0)killEnemy(i);}break;case 3:shieldTicks=100;break;case 4:case 11:if(t>=0)damageEnemies(E[t].x,E[t].y,power==4?85:105,power==4?100:70,0);break;case 5:hp=ci(hp+25,0,mhp);for(int i=0;i<MAXE;i++)if(E[i].alive&&dist2(px,py,E[i].x,E[i].y)<10000)E[i].hp-=22;break;case 8:hp=ci(hp+40,0,mhp);shieldTicks=70;break;case 9:for(int i=0;i<MAXE;i++)if(E[i].alive&&dist2(px,py,E[i].x,E[i].y)<110*110){E[i].hp-=28;E[i].x=ci(E[i].x+(E[i].x<px?-18:18),8,312);}break;case 10:hasteTicks=150;break;case 13:case 15:for(int i=0;i<MAXE;i++)if(E[i].alive&&dist2(px,py,E[i].x,E[i].y)<150*150){E[i].hp-=power==13?38:65;if(power==15)E[i].freeze=30;}break;case 16:hp=ci(hp+15,0,mhp);for(int i=0;i<MAXE;i++)if(E[i].alive&&dist2(px,py,E[i].x,E[i].y)<120*120){E[i].hp-=35;E[i].freeze=70;}break;case 18:hp=ci(hp+25,0,mhp);shieldTicks=120;break;}for(int i=0;i<MAXE;i++)if(E[i].alive&&E[i].hp<=0)killEnemy(i);}
static void updateShots(){for(int s=0;s<MAXS;s++)if(S[s].alive){Shot&b=S[s];b.x+=b.vx;b.y+=b.vy;b.life--;if(b.life<=0||b.x<2||b.x>318||b.y<27||b.y>238){b.alive=0;continue;}for(int i=0;i<MAXE;i++)if(E[i].alive&&dist2(E[i].x,E[i].y,b.x,b.y)<100){E[i].hp-=b.dmg;E[i].flash=2;if(E[i].hp<=0)killEnemy(i);if(!b.pierce){b.alive=0;break;}}}}
static void updateEnemies(){for(int i=0;i<MAXE;i++)if(E[i].alive){Enemy&e=E[i];if(e.freeze>0){e.freeze--;continue;}int dx=px-e.x,dy=py-e.y;if(dx)e.x+=dx>0?e.spd:-e.spd;if(dy)e.y+=dy>0?e.spd:-e.spd;e.x=ci(e.x,5,315);e.y=ci(e.y,30,207);if(e.flash)e.flash--;if(!invuln&&!shieldTicks&&dist2(px,py,e.x,e.y)<150){hp-=e.dmg;invuln=18;if(hp<=0){hp=0;scene=DEAD;}}}}
static void openShop();
static void updatePlay(){gameTick++;if(invuln)invuln--;if(shieldTicks)shieldTicks--;if(hasteTicks)hasteTicks--;if(powerCD)powerCD--;if(spawnLeft>0){spawnClock++;if(spawnClock>=(wave%5==0?1:13)){spawnClock=0;spawnEnemy();spawnLeft--;}}updateEnemies();updateShots();int t=nearest();fireClock++;int rate=weapons[weapon].rate*100/bonusRate;if(hasteTicks)rate/=2;if(rate<2)rate=2;if(t>=0&&fireClock>=rate){fireClock=0;Weapon&w=weapons[weapon];int dmg=w.dmg*(100+bonusDamage-100)/100;addShot(E[t].x,E[t].y,dmg,w.count+extraShots,w.pierce);}if(spawnLeft==0&&alive==0&&scene==PLAY){if(wave%5!=0)openShop();else scene=CHEST;}}
static void applyUpgrade(int n){switch(n){case 0:bonusDamage+=25;break;case 1:bonusRate+=20;break;case 2:extraShots++;break;case 3:bonusSpeed+=12;break;case 4:mhp+=30;hp=ci(hp+30,0,mhp);break;case 5:hp=mhp;break;case 6:if(weapon<WEAPONS)weapons[weapon].level=ci(weapons[weapon].level+1,0,5);break;}}
static void buyPower(int p){if(p<0||p>=POWERS||powers[p].unlock>island||gold<powers[p].cost)return;gold-=powers[p].cost;power=p;hasPower=1;}
// Pixel-art sprites inspired by the original HTML game's palette.
// Tiny fixed bitmaps keep rendering cheap on the calculator.
static const char* SPR_PLAYER[]={"....yy....","...yyyy...","..bbbbbb..",".bbccbbbb.",".bbckkbbbo.",".bbbbbbbbbo",".bbbbbbbb..","..bbbbbb...","...b..b....","...BB.BB...","..BB...BB.."};
static const char* SPR_CRAB[]={".rr......rr.","rRRr....rRRr","rR.rw..w.r.Rr",".rrrrrrrrrr.","..rrrrrrrr..",".rrrkrrkrrr.","..rrrrrrrr..",".R.R....R.R."};
static const char* SPR_SLIME[]={"...pppp...",".pppppppp.","ppwwppwwpp","ppwkppkwpp","pppppppppp",".ppkkkkpp.","..pppppp.."};
static const char* SPR_FLYER[]={"...cccc...",".cccccccc.","ccwwccccwwcc","cccckkkkcccc",".cccccccc.","..cc..cc.."};
static const char* SPR_BOSS[]={"....yyyy....","..yyFFFFyy..",".yFFFFFFFFy.","yFFkkFFkkFFy","yFFFFFFFFFFy",".yFFFFFFFFy.","..yFFFFFFy..","...YY..YY..."};
static const char* SPR_CHEST[]={".nnnnnnnnnn.","nNNNNNNNNNNn","nnnyyyyyynnn","nnyyyYYyyynn","nnyyyYYyyynn","nnnyyyyyynnn","nNNNNNNNNNNn",".nnnnnnnnnn."};
// Variantes thematiques compactes : un ennemi et un boss distincts par ile.
static const char* SPR_ISLAND[6][8]={
 {"..rrrr..",".rRRRr.","rRwwRr","rRRRRRr",".rrrrr.","..r.r..",0,0},
 {"...FFFF...","..FFFFFF..",".FFHFFHFF.","FFFFFFFFFF",".FFkkkkFF.","..FFFFFF..","...F..F...",0},
 {"...cccc...","..cccccc..",".ccwwccww.","cccckkkkcc",".cccccccc.","..cc..cc..",0,0},
 {"...YYYY...","..YYYYYY..",".YYwwYYww.","YYYYkkkkYY",".YYYYYYYY.","..YY..YY..",0,0},
 {"..pppppp..",".pppppppp.","ppwwppwwpp","pppkkkkppp",".pppppppp.","..pp..pp..",0,0},
 {"...yyyy...","..yyyyyy..",".yyccyycc.","yyyykkkkyy",".yyyyyyyy.","..yy..yy..",0,0}
};
static const char* SPR_BOSSES[6][10]={
 {"....rrrr....","..rrRRRRrr..",".rRRRRRRRRr.","rRRwwRRwwRRr","rRRRRkkkkRRr","rRRRRRRRRRRr",".rRRRRRRRRr.","..rrRRRRrr..","...rr..rr...",0},
 {"....FFFF....","..FFFFFFFF..",".FFHHFFHHFF.","FFFFFFFFFFFF","FFHHFFFFFFHHFF","FFFFFFFFFFFF",".FFFFFFFFFF.","..FFFFFF..FF..","...FF....FF...",0},
 {"....cccc....","..cccccccc..",".ccwwccwwcc.","cccckkkkcccc","cccccccccccc",".cccccccccc.","..cccccccc..","...cc....cc...",0},
 {"....YYYY....","..YYYYYYYY..",".YYwwYYwwYY.","YYYYkkkkYYYY","YYYYYYYYYYYY",".YYYYYYYYYY.","..YYYYYYYY..","...YY....YY...",0},
 {"...pppppp...","..pppppppp..",".ppwwppwwpp.","ppppkkkkpppp","pppppppppppp",".pppppppppp.","..pppppppp..","...pp....pp...",0},
 {"....yyyy....","..yyyyyyyy..",".yyccyyccyy.","yyyykkkkyyyy","yyyyyyyyyyyy",".yyyyyyyyyy.","..yyyyyyyy..","...yy....yy...",0}
};
// Pixel-art source sprites ported from the user's original HTML game.
static const char* ORIG_PLAYER[]={
"......y.y.....",".....yyyy.....","...bbbbbbb....","..bbcccbbbb...",".bbbccbbbwkbo.",".bbbbbbbbbbbbo",".bbbbbbbbbbbo.",".BbbbbbbbbbB..","..BBbbbbbBB...","...bbbbbbb....","...bB..bB.....","...BB..BB....."
};
static const char* ORIG_CRAB[]={
".rr........rr.","rRRr......rRRr","rR.r.w..w.r.Rr",".rrrrw..wrrrr.","..rrrrrrrrrr..",".rrrrkrrkrrrr.","..rrrrrrrrrr..",".R.R.R..R.R.R.","R..R......R..R"
};
static const char* ORIG_SLIME[]={
"....pppp....","..pppppppp..",".ppwwppwwpp.",".ppwkppkwpp.","pppppppppppp","ppppkkkkpppp","pPpppppppPpp",".PPPPPPPPPP.","..P.PP.PP.P."
};
static const char* ORIG_GULL[]={
"........wwww............","......wwwwwwww..........",".....wwwwwwwwww.........","....wwwwwwwkwwww........","....wwwwwwwwwwwoooo.....","...wwwwwwwwwwwwwooooy...","...wwwwwwwwwwwwwwwoo....","..wwsssswwwwwwwwww......",".wwssssssswwwwwww.......","wwsssssssssswwww........","wsssssSSssssswww........",".sssSSSSSssswww.........","..sSSSSSSsswww..........","...sSSSSsssw............","....oo..oo..............","....o....o.............."
};
static const char* ORIG_KRAKEN[]={
"......vvvvvvvv......","....vvvvvvvvvvvv....","...vvVvvvvvvvvVvv...","..vvvvvvvvvvvvvvvv..","..vvwwvvvvvvvvwwvv..","..vvwkvvvvvvvvwkvv..","..vvvvvvvvvvvvvvvv..","...vvvvvvkkvvvvvv...","....vvvvvkkvvvvv....",".v..vVvvVvvVvvVv..v.","vv..vv.vv..vv.vv..vv","v..vv..vv..vv..vv..v","..vv...v....v...vv..",".vv...vv....vv...vv."
};
static const char* ORIG_KING[]={
"......y..y..y..y......","......yyyyyyyyyy......","rrrr..rrrrrrrrrr..rrrr","rRRr.rrwwrrrrwwrr.rRRr","rR.r.rrwkrrrrwkrr.r.Rr","rrrr.rrrrrrrrrrrr.rrrr","..rr.rrrrkkkkrrrr.rr..","....rrrrrrrrrrrrrr....","...RrrRrrRrrRrrRrrR...","..R..R..R....R..R..R.."
};
static const char* ORIG_GOLEM[]={
"......dddddddd......",".....dSSSSSSSSd.....","....dSSSSSSSSSSd....","....dSyySSSSyySd....","....dSyySSSSyySd....","....dSSSSSSSSSSd....","..ddddSSeeeeSSdddd..","..dSSddSSSSSSddSSd..",".dSSSSdeSSSSedSSSSd.",".dSSSSdSSeeSSdSSSSd.",".dSSSd.dSSSSd.dSSSd.","..ddd..dSeeSd..ddd..","......dSSSSSSd......","......dSSdSSSd......",".....ddSd..dSdd.....",".....dSSd..dSSd.....",".....dddd..dddd....."
};
static const char* ORIG_PENG[]={
"...kkkk...","..kkkkkk..","..kwkkwk..","..kooook..",".kkwwwwkk.",".kwwwwwwk.",".kwwwwwwk.",".kkwwwwkk.","..kkkkkk..","..oo..oo.."
};
static const char* ORIG_YETI[]={
"....bbbbbb....","...bbbbbbbb...","..bbkbbbbkbb..","..bbbbbbbbbb..","..bbbkkkkbbb..",".bbbbbbbbbbbb.","bbBBBbbbbBBBbb","bbbBbbbbbbBbbb",".bbbbbbbbbbbb.","..bbbbbbbbbb..","..bbbb..bbbb..",".BBBBB..BBBBB."
};
static const char* ORIG_MAGE[]={
"...vvvv...","..vvvvvv..",".vvcvvcvv.",".vvvvvvvv.",".vVvvvvVv.",".vvvvvvvv.","..vVvvVv..","..vvvvvv..",".v.vvvv.v.","...v..v..."
};
static const char* ORIG_SNOW[]={
"....cccc....","..ccwwwwcc..",".cwwkwwkwwc.",".cwwwwwwwwc.","cwwwwkkwwwwc","cwwwwwwwwwwc",".cwwwwwwwwc.","..cccccccc.."
};
static const char* ORIG_CINDER[]={
"...hFh...","..hfffh..",".FffffF.","FffkffF","FffffffF",".FffffF.","..FfF..","..j.j.."
};
static const char* ORIG_PYROMANCER[]={
"...hhh...","..hFhFh..",".FFfFfFF.",".FfkkkfF.","..FFFFF..",".jFfFfFj.","..JJJJ..","..J..J.."
};
static const char* ORIG_MAGMA[]={
"...HHHH...","..HFFFFH..",".HFFhhFFH.","HFFhkkhFFH","HFFFFFFFFH",".HFFjjFFH.","..HFFFFH..","..JJ..JJ.."
};
static const char* ORIG_EMBERBAT[]={
"f..f..f","ff.F.ff","FfffffF","FfkkkfF",".FffffF.","..j.j.."
};
static const char* ORIG_VOLCANOBOSS[]={
".......hhhh.......",".....hhFFFFhh.....","....hFFFFFFFFh....","...hFFHHFFHHFFh...","..hFFFFFFFFFFFFh..",".hFFFhhFFFFhhFFFh.",".FFFFFkkkkFFFFF..","hFFFFFkkkkFFFFFh.","hFFFFFFFFFFFFFFh.","hFFHFFFFFFFFHFFh.",".hFFFFFFFFFFFFh..","..hFFHHHHHHFFh...","...hFFFFFFFFh....","....hFFFFFFh.....","...HH......HH....","..HHH......HHH..."
};
static const char* ORIG_SCORP[]={
".t.......t.","tt.t...t.tt","t.ttttttt.t",".ttkttkttt.","..ttttttt.o",".t.t.t.t.o.","t..t.t.t..."
};
static const char* ORIG_MUMMY[]={
"..zzzz..",".zzkzkz.",".zzzzzz.","zzzzzzzz","z.zzzz.z","..zzzz..","..z..z..","..zz.zz."
};
static const char* ORIG_SPHINX[]={
"...TTTT...","..TTkTkTT.","..TTTTTT..","TTTTTTTTTT","TtTTTTTTtT","TTTTTTTTTT","tt......tt"
};
static const char* ORIG_SNAKE[]={
"..uuuu..",".uukukk.","..uuuu..","...uuu..","..uuu...",".uuu....","uuU....."
};
static const char* ORIG_FROG[]={
".wu...uw.","uk.uuu.ku",".uuuuuuu.","uuuuuuuuu","uUuuuuuUu","U.U...U.U"
};
static const char* ORIG_WITCH[]={
"....q....","...qqq...",".qqqqqqq.","...ooo...","..okoko..","...ooo...","..qqqqq..",".qqqqqqq.","..q...q.."
};
static const char* ORIG_CROC[]={
".......uuuu.","uuuuuuuukuuu","uUuUuUuuuuuu",".UuuuuuuuuwU","..U.U..U.U.."
};
static const char* ORIG_BAT[]={
"d.....d","dd.d.dd","ddddddd","dwdddwd",".ddddd.","..d.d.."
};
static const char* ORIG_CLOUD[]={
"..www...",".wwwwww.","wwwkwkww","wwwwwwww",".ww..ww."
};
static const char* ORIG_ANGEL[]={
"...yy...","..yyyy..",".wwkkww.","w.wwww.w","ww.ww.ww","..wwww..","..w..w.."
};
static const char* ORIG_GRIFFON[]={
"...oo....","..oowk...",".oooooo.o","ooooooooo","oo.oo.oo.","o..o..o.."
};

static Color spriteColor(char c){switch(c){case 'y':return GOLD;case 'Y':return Color(0xb8860b);case 'b':return CYAN;case 'B':return Color(0x1f7f94);case 'c':return Color(0xa6f4fa);case 'k':return Color(0x1a1020);case 'o':return Color(0xf2a229);case 'r':return RED;case 'R':return Color(0x9a1f1a);case 'p':return Color(0xe066c8);case 'P':return Color(0x8a2f80);case 'v':return Color(0xa94bd6);case 'V':return Color(0x5a2a8a);case 's':return Color(0xc8c8d0);case 'S':return Color(0x6a6a7a);case 'd':return Color(0x3a3340);case 'e':return Color(0xff8a1f);case 'l':return Color(0x7fd6f5);case 'm':return Color(0xd8431c);case 'F':return Color(0xc92d18);case 'h':return Color(0xffd34a);case 'H':return Color(0x7d2118);case 'j':return Color(0xff9b32);case 'J':return Color(0x4b2524);case 'g':return Color(0x58c244);case 'G':return Color(0x2f7a2a);case 'u':return Color(0x4a8a2a);case 'U':return Color(0x2a4a1a);case 'T':return Color(0xe8c46a);case 't':return Color(0xb8703a);case 'z':return Color(0xf0e8d0);case 'q':return Color(0x7a4a90);case 'w':return WHITE;default:return BLACK;}}
static void drawSprite(const char*const* rows,int h,int cx,int bottom,int scale=1){
 for(int y=0;y<h;y++){const char* row=rows[y];if(!row)continue;int x=0;while(row[x]){char c=row[x];if(c=='.'){x++;continue;}int start=x;while(row[x]==c)x++;box(cx+((start-(int)strlen(row)/2)*scale),bottom-h*scale+y*scale,(x-start)*scale,scale,spriteColor(c));}}
}
static void drawEnemy(const Enemy&e){
 int bob=((gameTick/5+(e.x&3))%2);
 if(e.role==BOSS){
   const char*const* boss=ORIG_KRAKEN; int h=14;
   if(island==0){boss=ORIG_KRAKEN;h=14;} else if(island==1){boss=ORIG_VOLCANOBOSS;h=16;}
   else if(island==2){boss=ORIG_YETI;h=12;} else if(island==3){boss=ORIG_SPHINX;h=7;}
   else if(island==4){boss=ORIG_WITCH;h=9;} else {boss=ORIG_GRIFFON;h=6;}
   drawSprite(boss,h,e.x,e.y+h/2+bob,2);bar(e.x-22,e.y-22,44,4,e.hp,e.mhp,RED);
 } else if(e.role==FLYER){
   const char*const* flyer=island==0?ORIG_GULL:island==1?ORIG_EMBERBAT:island==2?ORIG_BAT:island==3?ORIG_BAT:island==4?ORIG_BAT:ORIG_CLOUD;
   int h=island==0?16:island==1?6:island==5?5:6;drawSprite(flyer,h,e.x,e.y+6-bob,1);
 } else if(e.role==HEAVY){
   const char*const* heavy=island==0?ORIG_SLIME:island==1?ORIG_MAGMA:island==2?ORIG_SNOW:island==3?ORIG_MUMMY:island==4?ORIG_CROC:ORIG_ANGEL;
   int h=island==0?9:island==1?8:island==2?8:island==3?8:island==4?5:7;drawSprite(heavy,h,e.x,e.y+h/2+bob,1);
 } else {
   const char*const* basic=island==0?ORIG_CRAB:island==1?ORIG_CINDER:island==2?ORIG_PENG:island==3?ORIG_SCORP:island==4?ORIG_FROG:ORIG_GRIFFON;
   int h=island==0?9:island==1?8:island==2?10:island==3?7:island==4?6:6;drawSprite(basic,h,e.x,e.y+h/2+bob,1);
 }
 if(e.flash)box(e.x-3,e.y-3,6,6,WHITE);
 if(e.role!=BOSS&&e.hp<e.mhp)bar(e.x-7,e.y-11,14,2,e.hp,e.mhp,GREEN);
}
static void drawWorld(){clear(sea[island]);for(int y=30;y<H;y+=16)for(int x=0;x<W;x+=16)if(((x/16+y/16)%3)==0)box(x,y,7,2,Color(0x18aeff));box(0,0,W,26,NAVY);txt("ARCHIPEL ENGLOUTI",6,7,WHITE,NAVY);char b[48];snprintf(b,sizeof(b),"ILE %d/6 VAGUE %d",island+1,wave);txt(b,204,7,GOLD,NAVY);txt(islandNames[island],7,30,WHITE,sea[island]);for(int bi=0;bi<MAXE;bi++)if(E[bi].alive&&E[bi].role==BOSS){txt(bossNames[island],108,30,GOLD,sea[island]);break;}
 box(26,42,268,163,land[island]);box(39,53,242,141,sea[island]);box(53,66,214,115,land[island]);box(65,77,190,92,sea[island]);for(int i=0;i<8;i++){int rx=55+(i*31)%210,ry=70+(i*19)%100;box(rx,ry,5,5,island%2?GOLD:GREEN);}
 for(int i=0;i<MAXE;i++)if(E[i].alive)drawEnemy(E[i]);
 for(int i=0;i<MAXS;i++)if(S[i].alive)box(S[i].x-2,S[i].y-2,5,5,weapons[weapon].color);
 if(!invuln||gameTick%4<2){drawSprite(ORIG_PLAYER,12,px,py+9+(gameTick/6%2),1);box(px-4,py+3,2,2,WHITE);}if(shieldTicks){box(px-9,py-11,18,1,CYAN);box(px-9,py+10,18,1,CYAN);box(px-9,py-11,1,22,CYAN);box(px+8,py-11,1,22,CYAN);}
 box(0,211,320,29,NAVY);snprintf(b,sizeof(b),"PV %d/%d OR %d XP %d/%d",hp,mhp,gold,xp,need);txt(b,5,216,WHITE,NAVY);bar(5,230,90,5,hp,mhp,RED);bar(104,230,70,5,xp,need,GOLD);txt(weapons[weapon].name,185,216,CYAN,NAVY);if(hasPower){snprintf(b,sizeof(b),"P:%d",powerCD/30);txt(b,274,230,GOLD,NAVY);}}
static void drawTitle(){clear(NAVY);box(0,0,320,64,OCEAN);txt("ARCHIPEL",104,12,WHITE,OCEAN);txt("ENGLOUTI",104,32,GOLD,OCEAN);box(24,83,272,91,SAND);box(38,97,244,63,GREEN);txt("6 ILES A LIBERER",94,112,BLACK,GREEN);txt("13 FUSIONS SECRÈTES",73,132,BLACK,GREEN);if(saveAvailable){txt("OK : CONTINUER",103,190,GOLD,NAVY);txt("SHIFT : NOUVELLE PARTIE",72,212,WHITE,NAVY);}else{txt("OK : COMMENCER",107,190,GOLD,NAVY);txt("FLECHES : BOUGER",93,212,WHITE,NAVY);}}
static void drawLevel(){clear(NAVY);txt("NIVEAU SUPERIEUR !",85,30,GOLD,NAVY);txt("CHOISIS TON AMELIORATION",55,56,WHITE,NAVY);const char*o[7]={"DEGATS +25%","CADENCE +20%","TIR SUPPLEMENTAIRE","VITESSE +12%","+30 PV MAX","SOIN COMPLET","ARME +1 NIVEAU"};for(int i=0;i<3;i++){int q=choice[i];box(25,82+i*39,270,30,i==selected?OCEAN:NAVY);txt(o[q],42,92+i*39,i==selected?GOLD:WHITE,i==selected?OCEAN:NAVY);}txt("HAUT/BAS PUIS OK",93,220,WHITE,NAVY);}
static void drawChest(){clear(NAVY);txt("BOSS VAINCU !",103,34,GOLD,NAVY);drawSprite(SPR_CHEST,8,160,151,4);txt("COFFRE DU BOSS",91,172,WHITE,NAVY);char b[48];snprintf(b,sizeof(b),"ARME : %s",weapons[shopChoice].name);txt(b,70,190,CYAN,NAVY);txt("OK : OUVRIR",108,219,WHITE,NAVY);}
static void drawShop(){clear(NAVY);txt("CAMP DE L'EXPEDITION",69,22,GOLD,NAVY);txt("OR DISPONIBLE",108,44,WHITE,NAVY);char b[32];snprintf(b,sizeof(b),"%d PIECES",gold);txt(b,130,59,CYAN,NAVY);const char*o[4]={"POUVOIR : ACHETER / CHANGER","FORGE : AMELIORER / FUSIONNER","ARMURERIE : CHANGER D'ARME","VAGUE SUIVANTE"};for(int i=0;i<4;i++){box(17,83+i*32,286,25,i==shopChoice?OCEAN:NAVY);txt(o[i],27,90+i*32,i==shopChoice?GOLD:WHITE,i==shopChoice?OCEAN:NAVY);}txt("HAUT/BAS PUIS OK",94,224,WHITE,NAVY);}
static void drawPowerShop(){clear(NAVY);txt("MARCHAND DE POUVOIRS",69,18,GOLD,NAVY);int shown=selected;char b[64];snprintf(b,sizeof(b),"%s",powers[shown].name);txt(b,90,78,CYAN,NAVY);snprintf(b,sizeof(b),"PRIX : %d OR",powers[shown].cost);txt(b,117,108,WHITE,NAVY);snprintf(b,sizeof(b),"DISPONIBLE DES ILES : %d",powers[shown].unlock+1);txt(b,76,132,WHITE,NAVY);if(powers[shown].unlock>island)txt("POUVOIR VERROUILLE",87,158,RED,NAVY);else if(gold<powers[shown].cost)txt("PAS ASSEZ D'OR",103,158,RED,NAVY);else txt("OK : ACHETER / EQUIPER",82,158,GREEN,NAVY);txt("GAUCHE/DROITE : DEFILER",75,203,WHITE,NAVY);txt("BAS : RETOUR",118,222,CYAN,NAVY);}
static void drawForge(){clear(NAVY);txt("FORGE DES ARMES",93,16,GOLD,NAVY);if(forgeMode==0){txt("3 DOUBLONS = +1 NIVEAU",76,45,WHITE,NAVY);char b[48];snprintf(b,sizeof(b),"%s  x%d  NIV %d",weapons[weapon].name,weapons[weapon].qty,weapons[weapon].level);txt(b,20,88,CYAN,NAVY);txt("OK : FORGER SI 3 EXEMPLAIRES",30,139,WHITE,NAVY);txt("DROITE : MODE FUSION",69,218,GOLD,NAVY);}else{char a[48],b[48];snprintf(a,sizeof(a),"ARME A : %s",weapons[forgeA].name);snprintf(b,sizeof(b),"ARME B : %s",weapons[forgeB].name);txt(a,16,75,CYAN,NAVY);txt(b,16,104,CYAN,NAVY);txt("GAUCHE/DROITE : CHOIX A",48,143,WHITE,NAVY);txt("HAUT/BAS : CHOIX B",62,164,WHITE,NAVY);txt("OK : FUSIONNER",91,193,GOLD,NAVY);} }
static void drawArmory(){clear(NAVY);txt("ARMURERIE",118,16,GOLD,NAVY);char b[48];snprintf(b,sizeof(b),"ARME %d/%d",weapon+1,WEAPONS);txt(b,126,44,WHITE,NAVY);txt(weapons[weapon].name,95,85,CYAN,NAVY);snprintf(b,sizeof(b),"DEGATS %d  TIR %d",weapons[weapon].dmg,weapons[weapon].rate);txt(b,73,111,WHITE,NAVY);snprintf(b,sizeof(b),"POSSEDE : %d  NIV %d",weapons[weapon].qty,weapons[weapon].level);txt(b,69,137,GOLD,NAVY);txt("GAUCHE/DROITE : DEFILER",54,190,WHITE,NAVY);txt("OK : EQUIPER  BAS : RETOUR",45,216,CYAN,NAVY);}
static void drawDead(){clear(NAVY);txt("EXPEDITION INTERROMPUE",65,61,RED,NAVY);char b[40];snprintf(b,sizeof(b),"SCORE : %d",score);txt(b,126,104,WHITE,NAVY);snprintf(b,sizeof(b),"VAGUE : %d",wave);txt(b,130,128,GOLD,NAVY);txt("OK : RECOMMENCER",94,190,WHITE,NAVY);}
static void drawVictory(){clear(NAVY);txt("ARCHIPEL CONQUIS !",83,63,GOLD,NAVY);txt("LES 6 ILES SONT LIBEREES",63,106,WHITE,NAVY);txt("TU ES LE GARDIEN DES MERS",57,130,CYAN,NAVY);txt("OK : REJOUER",111,190,WHITE,NAVY);}
static void render(){switch(scene){case TITLE:drawTitle();break;case PLAY:drawWorld();break;case LEVELUP:drawLevel();break;case CHEST:drawChest();break;case SHOP:drawShop();break;case POWERSELLER:drawPowerShop();break;case FORGE:drawForge();break;case ARMORY:drawArmory();break;case DEAD:drawDead();break;case VICTORY:drawVictory();break;}}
static void openShop(){scene=SHOP;shopChoice=0;saveNow();}
static void claimChest(){if(weapons[shopChoice].owned){weapons[shopChoice].qty++;}else{weapons[shopChoice].owned=1;weapons[shopChoice].qty=1;}weapon=shopChoice;recalcOwned();scene=SHOP;shopChoice=0;saveNow();}
static void forgeUpgrade(){Weapon&w=weapons[weapon];if(w.qty>=3&&w.level<5){w.qty-=2;w.level++;w.dmg=w.dmg*120/100;w.rate=w.rate*95/100;if(w.rate<2)w.rate=2;saveNow();}}
static void fuse(){if(forgeA==forgeB||!weapons[forgeA].owned||!weapons[forgeB].owned)return;for(int i=0;i<13;i++)if((recipeA[i]==forgeA&&recipeB[i]==forgeB)||(recipeA[i]==forgeB&&recipeB[i]==forgeA)){int out=recipeOut[i];if(weapons[forgeA].qty>0&&weapons[forgeB].qty>0&&!weapons[out].owned){weapons[forgeA].qty--;weapons[forgeB].qty--;weapons[out].owned=1;weapons[out].qty=1;weapon=out;recalcOwned();saveNow();}return;}}
static void nextAfterShop(){if(wave%10==0&&island<5){island++;}if(island==5&&wave>=60){scene=VICTORY;return;}scene=PLAY;startWave();}

int main(){saveAvailable=loadSave();render();while(true){Keyboard::State k=Keyboard::scan();
 if(scene==TITLE){if(k.keyDown(Keyboard::Key::OK)){if(saveAvailable)continueGame();else newGame();}if(saveAvailable&&k.keyDown(Keyboard::Key::Shift))newGame();}
 else if(scene==PLAY){int step=5*bonusSpeed/100;if(k.keyDown(Keyboard::Key::Left))px-=step;if(k.keyDown(Keyboard::Key::Right))px+=step;if(k.keyDown(Keyboard::Key::Up))py-=step;if(k.keyDown(Keyboard::Key::Down))py+=step;px=ci(px,8,312);py=ci(py,34,205);if(k.keyDown(Keyboard::Key::OK))castPower();updatePlay();}
 else if(scene==LEVELUP){if(k.keyDown(Keyboard::Key::Up))selected=(selected+2)%3;if(k.keyDown(Keyboard::Key::Down))selected=(selected+1)%3;if(k.keyDown(Keyboard::Key::OK)){applyUpgrade(choice[selected]);scene=PLAY;}}
 else if(scene==CHEST){if(k.keyDown(Keyboard::Key::OK)){claimChest();}}
 else if(scene==SHOP){if(k.keyDown(Keyboard::Key::Up))shopChoice=(shopChoice+3)%4;if(k.keyDown(Keyboard::Key::Down))shopChoice=(shopChoice+1)%4;if(k.keyDown(Keyboard::Key::OK)){if(shopChoice==0){scene=POWERSELLER;selected=0;}else if(shopChoice==1){scene=FORGE;forgeMode=0;}else if(shopChoice==2)scene=ARMORY;else nextAfterShop();}}
 else if(scene==POWERSELLER){if(k.keyDown(Keyboard::Key::Left))selected=(selected+POWERS-1)%POWERS;if(k.keyDown(Keyboard::Key::Right))selected=(selected+1)%POWERS;if(k.keyDown(Keyboard::Key::OK)){buyPower(selected);scene=SHOP;saveNow();}if(k.keyDown(Keyboard::Key::Down))scene=SHOP;}
 else if(scene==FORGE){if(forgeMode==0){if(k.keyDown(Keyboard::Key::Left))weapon=(weapon+WEAPONS-1)%WEAPONS;if(k.keyDown(Keyboard::Key::Right))forgeMode=1; if(k.keyDown(Keyboard::Key::OK)){forgeUpgrade();scene=SHOP;saveNow();}else if(k.keyDown(Keyboard::Key::Down))scene=SHOP;}else{if(k.keyDown(Keyboard::Key::Back)){forgeMode=0;}if(k.keyDown(Keyboard::Key::Left))forgeA=(forgeA+9-1)%9;if(k.keyDown(Keyboard::Key::Right))forgeA=(forgeA+1)%9;if(k.keyDown(Keyboard::Key::Up))forgeB=(forgeB+1)%9;if(k.keyDown(Keyboard::Key::Down))forgeB=(forgeB+9-1)%9;if(k.keyDown(Keyboard::Key::OK)){fuse();scene=SHOP;saveNow();}}}
 else if(scene==ARMORY){if(k.keyDown(Keyboard::Key::Left))weapon=(weapon+WEAPONS-1)%WEAPONS;if(k.keyDown(Keyboard::Key::Right))weapon=(weapon+1)%WEAPONS;if(k.keyDown(Keyboard::Key::OK)&&weapons[weapon].owned){scene=SHOP;saveNow();}if(k.keyDown(Keyboard::Key::Down))scene=SHOP;}
 else if(scene==DEAD||scene==VICTORY){if(k.keyDown(Keyboard::Key::OK))newGame();}
 render();Timing::msleep(35);
 }
}
