#pragma once
extern "C" {
#include <eadk.h>
}
namespace EADK {
class Color {
 public:
  constexpr Color(uint32_t rgb)
      : m_value(((rgb & 0xF80000) >> 8) | ((rgb & 0x00FC00) >> 5) | ((rgb & 0x0000F8) >> 3)) {}
  constexpr operator eadk_color_t() const { return (eadk_color_t)m_value; }
 private:
  uint16_t m_value;
};
class Point {
 public:
  constexpr Point(int x,int y):m_x(x),m_y(y){}
  operator eadk_point_t() const { return *reinterpret_cast<const eadk_point_t*>(this); }
 private:
  uint16_t m_x,m_y;
};
class Rect {
 public:
  constexpr Rect(int x,int y,int w,int h):m_x(x),m_y(y),m_w(w),m_h(h){}
  operator eadk_rect_t() const { return *reinterpret_cast<const eadk_rect_t*>(this); }
 private:
  uint16_t m_x,m_y,m_w,m_h;
};
namespace Display {
static inline void pushRectUniform(Rect r,Color c){eadk_display_push_rect_uniform(r,c);}
static inline void drawString(const char*s,Point p,bool large,Color fg,Color bg){eadk_display_draw_string(s,p,large,fg,bg);}
}
namespace Keyboard {
enum class Key:uint8_t{Left=0,Up=1,Down=2,Right=3,OK=4,Back=5,Home=6,Shift=12,Alpha=13,XNT=14,Var=15,Toolbox=16,Backspace=17,Exp=18,Ln=19,Log=20,Imaginary=21,Comma=22,Power=23,Sine=24,Cosine=25,Tangent=26,Pi=27,Sqrt=28,Square=29,Seven=30,Eight=31,Nine=32,LeftParenthesis=33,RightParenthesis=34,Four=36,Five=37,Six=38,Multiplication=39,Division=40,One=42,Two=43,Three=44,Plus=45,Minus=46,Zero=48,Dot=49,EE=50,Ans=51,EXE=52};
class State{public:constexpr State(uint64_t s=0):m_bits(s){}bool keyDown(Key k)const{return eadk_keyboard_key_down(*reinterpret_cast<const eadk_keyboard_state_t*>(this),(eadk_key_t)k);}private:uint64_t m_bits;};
static inline State scan(){return State(eadk_keyboard_scan());}
}
namespace Timing {static inline void msleep(uint32_t ms){eadk_timing_msleep(ms);}}
}
