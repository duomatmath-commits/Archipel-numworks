/*
 * NumWorks external-app storage adapter.
 * Based on Yaya-Cout's numworks-extapp-storage (MIT), with a reduced API
 * surface for this game. This uses undocumented Epsilon userland layout;
 * hardware/firmware validation is mandatory before relying on saves.
 */
#include "storage.h"
#include <string.h>
#include <stdint.h>
#include <stddef.h>

static uint32_t rev32(uint32_t v) {
  return ((v & 0x000000ffu) << 24) | ((v & 0x0000ff00u) << 8) |
         ((v & 0x00ff0000u) >> 8) | ((v & 0xff000000u) >> 24);
}
static uint32_t userlandAddress() {
  volatile uint32_t *a = (volatile uint32_t *)0x90010000u;
  volatile uint32_t *b = (volatile uint32_t *)0x90410000u;
  volatile uint32_t *c = (volatile uint32_t *)0x90020000u;
  volatile uint32_t *d = (volatile uint32_t *)0x90420000u;
  bool oldModel = (*a == rev32(0xfeedc0deu)) || (*b == rev32(0xfeedc0deu));
  bool newModel = (*c == rev32(0xfeedc0deu)) || (*d == rev32(0xfeedc0deu));
  if (oldModel && !newModel) return (*(volatile uint32_t *)0x20000004u) + 0x10000u - 8u;
  return (*(volatile uint32_t *)0x24000004u) + 0x20000u - 8u;
}
static uint32_t storageAddress() { return *(volatile uint32_t *)(userlandAddress() + 0x0cu); }
static uint32_t storageSize() { return *(volatile uint32_t *)(userlandAddress() + 0x10u); }
static bool validStorage(uint32_t a) { return *(volatile uint32_t *)a == rev32(0xBADD0BEEu); }
static char *nextFree() {
  uint32_t a = storageAddress(), size = storageSize();
  if (!a || !size || !validStorage(a)) return 0;
  char *p = (char *)a + 4, *end = (char *)a + size;
  while (p + 2 <= end) { uint16_t n = *(uint16_t *)p; if (!n) return p; if (n < 3 || p + n > end) return 0; p += n; }
  return 0;
}
extern "C" bool extapp_fileExists(const char *filename) {
  uint32_t a=storageAddress(), size=storageSize(); if(!a||!size||!validStorage(a)) return false;
  char *p=(char*)a+4,*end=(char*)a+size;
  while(p+2<=end){uint16_t n=*(uint16_t*)p;if(!n)break;if(n<3||p+n>end)break;if(strcmp(p+2,filename)==0)return true;p+=n;}return false;
}
extern "C" const char *extapp_fileRead(const char *filename,size_t *len) {
  uint32_t a=storageAddress(),size=storageSize();if(!a||!size||!len||!validStorage(a))return 0;
  char *p=(char*)a+4,*end=(char*)a+size;
  while(p+2<=end){uint16_t n=*(uint16_t*)p;if(!n)break;if(n<3||p+n>end)break;char *name=p+2;size_t nl=strlen(name)+1;if(strcmp(name,filename)==0&&2+nl<=n){*len=n-2-nl;return p+2+nl;}p+=n;}return 0;
}
extern "C" bool extapp_fileErase(const char *filename) {
  uint32_t a=storageAddress(),size=storageSize();if(!a||!size||!validStorage(a))return false;
  char *p=(char*)a+4,*end=(char*)a+size;
  while(p+2<=end){uint16_t n=*(uint16_t*)p;if(!n)break;if(n<3||p+n>end)break;if(strcmp(p+2,filename)==0){char *nf=nextFree();if(!nf)return false;memmove(p,p+n,(size_t)(nf-(p+n)));memset(nf-n,0,n);return true;}p+=n;}return false;
}
extern "C" bool extapp_fileWrite(const char *filename,const char *content,size_t len) {
  if(!filename||!content||len>60000)return false;
  char *p=nextFree();if(!p)return false;uint32_t a=storageAddress(),size=storageSize();
  size_t nl=strlen(filename)+1,total=2+nl+len;if(total>65535||(uint32_t)(p-(char*)a)+total>size)return false;
  *(uint16_t*)p=(uint16_t)total;memcpy(p+2,filename,nl);memcpy(p+2+nl,content,len);
  memset(p+total,0,(size_t)(((char*)a+size)-(p+total)));return true;
}
