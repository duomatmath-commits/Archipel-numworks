#ifndef ARCHIPEL_STORAGE_H
#define ARCHIPEL_STORAGE_H
#include <stddef.h>
#include <stdint.h>
#ifdef __cplusplus
extern "C" {
#endif
bool extapp_fileExists(const char *filename);
const char *extapp_fileRead(const char *filename, size_t *len);
bool extapp_fileWrite(const char *filename, const char *content, size_t len);
bool extapp_fileErase(const char *filename);
#ifdef __cplusplus
}
#endif
#endif
