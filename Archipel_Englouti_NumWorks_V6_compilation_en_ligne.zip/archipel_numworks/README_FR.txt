ARCHIPEL ENGLOUTI - PORTAGE NUMWORKS NATIF C++
================================================
Version V6 - sprites originaux + sauvegarde persistante experimentale.

CE QUI EST PRESENT
------------------
- Application native C++ / EADK, sans Python et sans navigateur.
- Jeu en 320 x 240 avec boucle a tableaux fixes.
- Six iles thematiques, six palettes de decor et six boss nommes.
- Sprites pixel-art repris des tableaux de sprites du HTML fourni :
  joueur, crabes, slimes, goelands, kraken, roi, golem, pingouins,
  yeti, mage, ennemis volcaniques, scorpions, momies, sphinx,
  grenouilles, sorcieres, crocodiles, nuages, anges et griffon.
- Animation legere par oscillation des personnages et clignotement de degats.
- 60 vagues de progression, boss toutes les cinq vagues.
- 22 armes (9 de base et 13 hybrides), 13 recettes de fusion.
- Doublons, niveaux d'armes, forge, armurerie et coffres de boss.
- 19 pouvoirs, marchand, ameliorations, experience et progression.
- Sons volontairement absents.

SAUVEGARDES
------------
Une sauvegarde de progression a deux emplacements est integree au code.
Elle conserve l'ile, la vague validee, les PV, l'or, l'XP, le niveau,
le score, les ameliorations, le pouvoir et l'inventaire complet des armes.
La sauvegarde est faite aux checkpoints du camp (apres une vague/boss et
apres les achats/fusions). Au lancement, OK reprend le dernier checkpoint ;
SHIFT demarre une nouvelle partie.

IMPORTANT : l'EADK officiel n'expose pas de stockage persistant standard.
L'adaptateur src/storage/storage.cpp reprend le principe de la bibliotheque
communautaire numworks-extapp-storage (Yaya-Cout, MIT) et lit/ecrit dans le
stockage Epsilon via des adresses internes non documentees. Cette methode
est experimentale et depend du modele/firmware. Elle N'A PAS ete testee sur
une vraie calculatrice dans cet environnement. Ne considere pas les saves
comme garanties avant un essai sur la NumWorks cible. Les deux slots et le
checksum reduisent le risque de corruption, sans garantir une protection
contre toute coupure ou incompatibilite de firmware.

LIMITES CONNUES
---------------
- V6 est une reconstruction native des mecaniques, pas le HTML qui tourne tel
  quel. Le HTML original est conserve dans reference/ pour comparaison.
- Les sprites pixel-art du HTML sont repris, mais les animations complexes,
  effets de particules, decors complets et toutes les variantes visuelles ne
  sont pas encore reproduits a l'identique.
- Les sons sont volontairement exclus.
- Aucun binaire NWA n'est inclus : arm-none-eabi-gcc/g++ n'est pas disponible
  dans l'environnement de preparation.
- La verification locale de syntaxe C++ ne remplace ni la compilation ARM,
  ni le test de l'adaptateur de stockage, ni un essai sur calculatrice.

VERIFICATION LOCALE
-------------------
Depuis ce dossier : ./tests/check_syntax.sh
Cette verification controle uniquement la syntaxe sur l'hote.

COMPILATION NUMWORKS
--------------------
Prerequis : arm-none-eabi-gcc, arm-none-eabi-g++ et Node.js.
Depuis ce dossier : make clean && make build
Le fichier attendu est output/Archipel_Englouti.nwa
Puis installer via l'outil d'applications externes NumWorks.
Documentation officielle :
https://github.com/numworks/epsilon/tree/master/epsilon/external_apps

Stockage communautaire de reference :
https://framagit.org/Yaya.Cout/numworks-extapp-storage

COMPILATION EN LIGNE SANS PC
----------------------------
Un workflow GitHub Actions est fourni dans .github/workflows/build-numworks.yml.
Voir BUILD_EN_LIGNE_FR.txt pour les etapes depuis un telephone. Le workflow
produit un artefact NWA uniquement apres une compilation reussie.
